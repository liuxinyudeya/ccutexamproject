create procedure test(IN a int, OUT b int)
begin
  select a;
  set a=50;
end;

