create procedure studenttest(IN sno varchar(20), OUT name varchar(20))
begin
  select name into name from student where studentno=sno;
end;

