create definer = root@localhost event updatePaper on schedule
  every '20' MINUTE
    starts '2019-03-19 12:42:07'
  enable
  do
  begin
    start transaction
      ;
      set @timenow = now();
      update paper set examstate='已完成' where endTime < @timenow;
    commit;
  end;

