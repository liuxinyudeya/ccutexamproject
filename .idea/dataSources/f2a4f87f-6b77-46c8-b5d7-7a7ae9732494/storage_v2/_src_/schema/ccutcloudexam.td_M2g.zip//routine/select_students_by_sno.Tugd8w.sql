create procedure select_students_by_sno(IN sno varchar(225), OUT name1 varchar(225))
BEGIN

  SELECT name  from student where studentno = sno into name1;

END;

