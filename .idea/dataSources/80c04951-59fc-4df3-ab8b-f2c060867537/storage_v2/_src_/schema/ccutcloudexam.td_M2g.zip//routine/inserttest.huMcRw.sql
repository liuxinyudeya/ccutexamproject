create procedure inserttest(IN id int, IN name varchar(20), IN sex int, IN age int)
begin
insert into user_test (id,name,sex,age) values (id,name,sex,age);
end;

