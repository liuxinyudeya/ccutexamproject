create definer = root@localhost event updatePaper on schedule
  every '1' HOUR
    starts '2019-02-23 14:14:40'
  enable
  do
  begin
    start transaction
      ;
      set @timenow = now();
      update paper set examstate='已完成' where endTime < @timenow;
    commit;
  end;

