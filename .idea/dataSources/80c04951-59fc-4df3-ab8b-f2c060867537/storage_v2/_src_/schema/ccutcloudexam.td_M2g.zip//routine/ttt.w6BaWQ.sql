create procedure ttt(IN name varchar(20), OUT count int)
begin
 select count(*) into count from user_test where name=name;
end;

